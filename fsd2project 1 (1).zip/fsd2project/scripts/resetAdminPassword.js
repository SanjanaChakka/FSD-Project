#!/usr/bin/env node
// scripts/resetAdminPassword.js
// Usage: node scripts/resetAdminPassword.js --username adminname --password NewP@ssw0rd

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.resolve(process.cwd(), '.env') });

const Admin = require(path.resolve(process.cwd(), 'models', 'Admin'));

function parseArgs() {
  const args = process.argv.slice(2);
  const out = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--username' || a === '-u') out.username = args[i+1], i++;
    else if (a === '--password' || a === '-p') out.password = args[i+1], i++;
    else if (a === '--help' || a === '-h') out.help = true;
  }
  return out;
}

(async function main(){
  const { username, password, help } = parseArgs();
  if (help || !username || !password) {
    console.log('\nReset an existing admin password.');
    console.log('Usage: node scripts/resetAdminPassword.js --username adminname --password NewP@ssw0rd');
    process.exit(help ? 0 : 1);
  }

  const MONGO_URL = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/eventDB';
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true });

    const admin = await Admin.findOne({ username });
    if (!admin) {
      console.error('Error: Admin not found with username:', username);
      process.exit(2);
    }

    const salt = await bcrypt.genSalt(10);
    const hashed = await bcrypt.hash(password, salt);
    admin.password = hashed;
    await admin.save();
    console.log('✅ Password updated for admin:', username);
    process.exit(0);
  } catch (err) {
    console.error('❌ Error updating password:', err.message || err);
    process.exit(3);
  }
})();
