const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Registration = require('../models/Registration');
const XLSX = require('xlsx');
const PDFDocument = require('pdfkit');

// GET /api/admin/registrations - protected, supports query filters
router.get('/registrations', auth, async (req, res) => {
  try {
    const { q, eventId, startDate, endDate, page = 1, limit = 50 } = req.query;
    const filter = {};
    if (q) filter.name = { $regex: q, $options: 'i' };
    if (eventId) filter.eventId = eventId;
    if (startDate || endDate) filter.registeredAt = {};
    if (startDate) filter.registeredAt.$gte = new Date(startDate);
    if (endDate) filter.registeredAt.$lte = new Date(endDate);

    const skip = (Number(page) - 1) * Number(limit);
    const total = await Registration.countDocuments(filter);
    const items = await Registration.find(filter).sort({ registeredAt: -1 }).skip(skip).limit(Number(limit));

    res.json({ total, page: Number(page), limit: Number(limit), items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/admin/export/xlsx - protected, returns xlsx file
router.get('/export/xlsx', auth, async (req, res) => {
  try {
    const regs = await Registration.find().sort({ registeredAt: -1 }).lean();
    const data = regs.map(r => ({
      Name: r.name,
      Email: r.email,
      Phone: r.phone,
      Department: r.department,
      Event: r.eventId,
      RegisteredAt: r.registeredAt
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Registrations');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Disposition', 'attachment; filename="registrations.xlsx"');
    res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Export failed' });
  }
});

// GET /api/admin/export/pdf - protected, returns PDF
router.get('/export/pdf', auth, async (req, res) => {
  try {
    const regs = await Registration.find().sort({ registeredAt: -1 }).lean();

    const doc = new PDFDocument({ margin: 30 });
    res.setHeader('Content-Disposition', 'attachment; filename="registrations.pdf"');
    res.type('application/pdf');
    doc.pipe(res);

    doc.fontSize(18).text('Registrations', { underline: true });
    doc.moveDown();

    regs.forEach(r => {
      doc.fontSize(12).text(`${r.name} — ${r.email} — ${r.phone} — ${r.department} — ${r.eventId}`);
      doc.moveDown(0.2);
    });

    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Export failed' });
  }
});

module.exports = router;
