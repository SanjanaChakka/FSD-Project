const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');
const nodemailer = require('nodemailer');

// POST: Register for an event
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, department, eventId } = req.body;

    if (!name || !email || !phone || !department || !eventId) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const newRegistration = new Registration({ name, email, phone, department, eventId });
    await newRegistration.save();

    // Nodemailer: Send confirmation email
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Event Registration Successful 🎉',
      text: `Hello ${name},\n\nYou have successfully registered for event ID: ${eventId}.\n\nThank you!`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) console.log('Email error:', error);
      else console.log('Email sent:', info.response);
    });

    res.status(201).json({ message: 'Registration successful! Confirmation email sent.' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

module.exports = router;
