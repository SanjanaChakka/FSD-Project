// Event management functions
let events = [];
let isEditing = false;

// Fetch all events
async function fetchEvents() {
    try {
        const response = await fetch('/api/events');
        if (!response.ok) throw new Error('Failed to fetch events');
        events = await response.json();
        renderEventsTable();
    } catch (error) {
        console.error('Error fetching events:', error);
        showNotification('Failed to load events', 'error');
    }
}

// Render events table
function renderEventsTable() {
    const tbody = document.getElementById('eventsTableBody');
    if (!tbody) return;

    tbody.innerHTML = events.map(event => `
        <tr>
            <td>${escapeHtml(event.title)}</td>
            <td>${new Date(event.date).toLocaleString()}</td>
            <td>${escapeHtml(event.category)}</td>
            <td>${event.capacity}</td>
            <td>
                <button class="action-btn edit" onclick="editEvent('${event._id}')">
                    <i class="bx bx-edit"></i>
                </button>
                <button class="action-btn delete" onclick="deleteEvent('${event._id}')">
                    <i class="bx bx-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Show notification
function showNotification(message, type = 'success') {
    alert(message); // You can replace this with a better notification system
}

// Open event form
function openEventForm() {
    const modal = document.getElementById('eventFormModal');
    if (!modal) return;

    document.getElementById('modalTitle').textContent = isEditing ? 'Edit Event' : 'Add New Event';
    modal.style.display = 'block';
}

// Close event form
function closeEventForm() {
    const modal = document.getElementById('eventFormModal');
    if (!modal) return;

    document.getElementById('eventForm').reset();
    document.getElementById('eventId').value = '';
    modal.style.display = 'none';
    isEditing = false;
}

// Handle form submission
async function handleEventSubmit(e) {
    e.preventDefault();
    
    const formData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        category: document.getElementById('category').value,
        date: document.getElementById('date').value,
        capacity: parseInt(document.getElementById('capacity').value)
    };

    const eventId = document.getElementById('eventId').value;
    const url = eventId ? `/api/events/${eventId}` : '/api/events';
    const method = eventId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) throw new Error('Failed to save event');

        await fetchEvents();
        closeEventForm();
        showNotification(eventId ? 'Event updated successfully' : 'Event created successfully');
    } catch (error) {
        console.error('Error saving event:', error);
        showNotification('Failed to save event', 'error');
    }
}

// Edit event
async function editEvent(eventId) {
    const event = events.find(e => e._id === eventId);
    if (!event) return;

    document.getElementById('eventId').value = event._id;
    document.getElementById('title').value = event.title;
    document.getElementById('description').value = event.description;
    document.getElementById('category').value = event.category;
    document.getElementById('date').value = new Date(event.date).toISOString().slice(0, 16);
    document.getElementById('capacity').value = event.capacity;

    isEditing = true;
    openEventForm();
}

// Delete event
async function deleteEvent(eventId) {
    if (!confirm('Are you sure you want to delete this event?')) return;

    try {
        const response = await fetch(`/api/events/${eventId}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Failed to delete event');

        await fetchEvents();
        showNotification('Event deleted successfully');
    } catch (error) {
        console.error('Error deleting event:', error);
        showNotification('Failed to delete event', 'error');
    }
}

// Search events
function searchEvents(query) {
    const filteredEvents = events.filter(event => 
        event.title.toLowerCase().includes(query.toLowerCase()) ||
        event.category.toLowerCase().includes(query.toLowerCase())
    );
    renderFilteredEvents(filteredEvents);
}

// Escape HTML to prevent XSS
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    fetchEvents();
    
    // Add search functionality
    const searchInput = document.getElementById('searchEvents');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => searchEvents(e.target.value));
    }
});