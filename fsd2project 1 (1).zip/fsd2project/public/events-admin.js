// events-admin.js
// Renders events on the public events page and exposes admin CRUD controls when logged in.

let isAdmin = false;
let events = [];

async function checkAdmin() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (res.ok) {
      const json = await res.json();
      if (json && json.admin) {
        isAdmin = true;
        document.getElementById('eventsControls').style.display = 'block';
        document.getElementById('addEventBtn').addEventListener('click', openEventForm);
      }
    }
  } catch (err) {
    // not logged in or endpoint unavailable
    isAdmin = false;
  }
}

async function fetchAndRenderEvents() {
  try {
    const res = await fetch('/api/events');
    if (!res.ok) throw new Error('Failed to load events');
    events = await res.json();
    // Only render dynamic events after the static events
    const dynamicEvents = document.getElementById('dynamicEvents');
    if (dynamicEvents) {
      dynamicEvents.innerHTML = events.map(ev => eventCardHtml(ev)).join('');
      attachCardListeners();
    }
  } catch (err) {
    console.error(err);
    const dynamicEvents = document.getElementById('dynamicEvents');
    if (dynamicEvents) {
      dynamicEvents.innerHTML = '<p class="text-center col-span-4">Failed to load additional events</p>';
    }
  }
}

function renderEvents(list) {
  const container = document.getElementById('eventsGrid');
  container.innerHTML = list.map(ev => eventCardHtml(ev)).join('');
  attachCardListeners();
}

function eventCardHtml(ev) {
  const dateStr = ev.date ? new Date(ev.date).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
  const categoryClass = (ev.category || '').toLowerCase().includes('tech') ? 'technical' : 'cultural';
  return `
    <div class="event-card ${categoryClass}" data-id="${ev._id}" data-aos="fade-up">
      <div class="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-105 hover:shadow-xl relative">
        <img src="${ev.image || 'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=1200&q=80'}" alt="${escapeHtml(ev.title)}" class="w-full h-48 object-cover">
        ${isAdmin ? adminCardOverlay() : ''}
        <div class="p-6">
          <span class="text-xs font-semibold ${categoryClass === 'technical' ? 'text-blue-600 bg-blue-100' : 'text-purple-600 bg-purple-100'} px-3 py-1 rounded-full">${escapeHtml(ev.category || '')}</span>
          <h3 class="text-xl font-bold mt-2">${escapeHtml(ev.title)}</h3>
          <p class="text-gray-600 mt-2">${escapeHtml(ev.description || '')}</p>
          <div class="flex flex-col gap-2 mt-4">
            <span class="text-sm text-gray-500 event-date">${dateStr}</span>
            <div class="flex gap-2">
              <a href="register.html?event=${encodeURIComponent(ev._id)}&title=${encodeURIComponent(ev.title)}" class="flex-1 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200 text-center font-semibold">Register</a>
              <a href="event-details.html?event=${encodeURIComponent(ev._id)}" class="flex-1 inline-block bg-white border border-blue-600 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition-all duration-200 text-center font-semibold">View Info</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function adminCardOverlay() {
  return `
    <div style="position:absolute;right:0;top:0;padding:0.5rem;display:flex;gap:0.5rem;">
      <button class="admin-edit-btn bg-white p-2 rounded-md shadow-sm" title="Edit">
        <i class="bx bx-edit"></i>
      </button>
      <button class="admin-delete-btn bg-white p-2 rounded-md shadow-sm" title="Delete">
        <i class="bx bx-trash"></i>
      </button>
    </div>
  `;
}

function attachCardListeners() {
  // Edit buttons
  document.querySelectorAll('.admin-edit-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const card = e.target.closest('.event-card');
      const id = card.getAttribute('data-id');
      editEvent(id);
    });
  });
  // Delete buttons
  document.querySelectorAll('.admin-delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const card = e.target.closest('.event-card');
      const id = card.getAttribute('data-id');
      if (!confirm('Delete this event?')) return;
      try {
        const res = await fetch(`/api/events/${id}`, { method: 'DELETE', credentials: 'same-origin' });
        if (!res.ok) throw new Error('Delete failed');
        await fetchAndRenderEvents();
        alert('Event deleted');
      } catch (err) {
        console.error(err);
        alert('Failed to delete');
      }
    });
  });
}

// ---------------- Modal CRUD UI ----------------
function openEventForm() {
  // create modal if not existing
  if (document.getElementById('evModal')) return showModal();
  const modal = document.createElement('div');
  modal.id = 'evModal';
  modal.innerHTML = `
    <div class="modal" style="display:block;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:10000;">
      <div class="modal-content" style="max-width:640px;margin:3rem auto;background:#fff;padding:1.5rem;border-radius:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;"><h3 id="evModalTitle">Add Event</h3><button id="evCloseBtn" class="close-btn">×</button></div>
        <form id="evForm">
          <input type="hidden" id="evId">
          <div class="form-group">
            <label>Title</label>
            <input id="evTitle" class="form-input" required />
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea id="evDesc" class="form-input" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label>Category</label>
            <input id="evCategory" class="form-input" />
          </div>
          <div class="form-group">
            <label>Date & Time</label>
            <input id="evDate" type="datetime-local" class="form-input" />
          </div>
          <div class="form-group">
            <label>Capacity</label>
            <input id="evCapacity" type="number" min="0" class="form-input" />
          </div>
          <div style="display:flex;justify-content:flex-end;gap:0.5rem;margin-top:1rem;">
            <button type="button" id="evCancel" class="filter-btn px-4 py-2 rounded-md bg-gray-200">Cancel</button>
            <button type="submit" class="filter-btn px-4 py-2 rounded-md bg-blue-600 text-white">Save</button>
          </div>
        </form>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  document.getElementById('evCloseBtn').addEventListener('click', closeModal);
  document.getElementById('evCancel').addEventListener('click', closeModal);
  document.getElementById('evForm').addEventListener('submit', onEvFormSubmit);
}

function showModal() {
  const m = document.querySelector('#evModal .modal');
  if (m) m.style.display = 'block';
}
function closeModal() {
  const modal = document.getElementById('evModal');
  if (modal) modal.remove();
}

async function onEvFormSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('evId').value;
  const payload = {
    title: document.getElementById('evTitle').value,
    description: document.getElementById('evDesc').value,
    category: document.getElementById('evCategory').value,
    date: document.getElementById('evDate').value,
    capacity: parseInt(document.getElementById('evCapacity').value) || 0
  };
  try {
    const url = id ? `/api/events/${id}` : '/api/events';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('Save failed');
    await fetchAndRenderEvents();
    closeModal();
    alert('Saved');
  } catch (err) {
    console.error(err);
    alert('Failed to save event');
  }
}

function editEvent(id) {
  const ev = events.find(x => x._id === id);
  if (!ev) return;
  openEventForm();
  document.getElementById('evModalTitle').textContent = 'Edit Event';
  document.getElementById('evId').value = ev._id;
  document.getElementById('evTitle').value = ev.title || '';
  document.getElementById('evDesc').value = ev.description || '';
  document.getElementById('evCategory').value = ev.category || '';
  if (ev.date) document.getElementById('evDate').value = new Date(ev.date).toISOString().slice(0,16);
  document.getElementById('evCapacity').value = ev.capacity || 0;
}

// Utilities
function escapeHtml(s){ if(!s) return ''; return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }

// Init
document.addEventListener('DOMContentLoaded', async () => {
  await checkAdmin();
  await fetchAndRenderEvents();

  // Filters (re-use existing filter buttons behaviour)
  const filterBtns = document.querySelectorAll('.filter-btn[data-filter]');
  if (filterBtns.length) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active', 'bg-blue-600', 'text-white'));
        btn.classList.add('active', 'bg-blue-600', 'text-white');
        const filter = btn.dataset.filter;
        document.querySelectorAll('.event-card').forEach(card => {
          if (filter === 'all' || card.classList.contains(filter)) card.style.display = 'block'; else card.style.display = 'none';
        });
      });
    });
  }
});
