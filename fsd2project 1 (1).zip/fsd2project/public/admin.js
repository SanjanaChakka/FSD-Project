let token = null;

async function handleLogin(evt) {
  evt.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  const res = await fetch('/api/auth/admin/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();
  if (res.ok) {
    token = data.token;
    document.getElementById('loginMsg').textContent = 'Logged in as ' + data.admin.username;
    document.getElementById('adminPanel').style.display = 'block';
    document.querySelector('.admin-login').style.display = 'none';
    loadRegistrations();
  } else {
    document.getElementById('loginMsg').textContent = data.message || 'Login failed';
  }
}

async function loadRegistrations(page = 1) {
  const q = document.getElementById('searchQ').value;
  const url = `/api/admin/registrations?q=${encodeURIComponent(q)}&page=${page}&limit=50`;
  const res = await fetch(url, { headers: { Authorization: 'Bearer ' + token } });
  if (res.status === 401) {
    alert('Unauthorized. Please login again.');
    return;
  }
  const data = await res.json();
  const container = document.getElementById('results');
  if (!data.items) { container.textContent = 'No results'; return; }

  let html = `<p>Total: ${data.total}</p>`;
  html += '<table class="admin-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>Event</th><th>RegisteredAt</th></tr></thead><tbody>';
  data.items.forEach(r => {
    html += `<tr><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.email)}</td><td>${escapeHtml(r.phone)}</td><td>${escapeHtml(r.department)}</td><td>${escapeHtml(r.eventId)}</td><td>${new Date(r.registeredAt).toLocaleString()}</td></tr>`;
  });
  html += '</tbody></table>';
  container.innerHTML = html;
}

function escapeHtml(s){ if(!s) return ''; return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function exportXLSX(){
  window.open('/api/admin/export/xlsx', '_blank');
}

function exportPDF(){
  window.open('/api/admin/export/pdf', '_blank');
}
