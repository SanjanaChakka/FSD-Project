const jwt = require('jsonwebtoken');

module.exports = function(req, res, next) {
  // Try Authorization header first
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  let token = null;
  if (authHeader) {
    const parts = authHeader.split(' ');
    if (parts.length === 2 && parts[0] === 'Bearer') token = parts[1];
  }

  // If no header token, try cookie (requires cookie-parser middleware)
  if (!token && req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) return res.status(401).json({ message: 'No token provided' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'change_this_secret');
    req.admin = decoded; // attach payload
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};
